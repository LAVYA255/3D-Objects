import React from 'react';
import Scene3DShowcase from './components/Scene3DShowcase';

function App() {
  return (
    <div className="w-full h-screen">
      <Scene3DShowcase />
    </div>
  );
}

export default App;